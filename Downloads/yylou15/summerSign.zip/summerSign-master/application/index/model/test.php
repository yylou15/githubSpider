<?php
/**
 * Created by PhpStorm.
 * User: USER9
 * Date: 2018/6/17
 * Time: 4:47
 */

namespace app\index\model;

use think\Model;
use think\db;
class test extends Model
{
    public function aaa(){
        $this->table();
    }
}