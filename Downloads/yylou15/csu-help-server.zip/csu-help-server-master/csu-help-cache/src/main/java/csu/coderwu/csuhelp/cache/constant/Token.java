package csu.coderwu.csuhelp.cache.constant;

/**
 * @author : coderWu
 * @date : Created on 16:51 2018/5/26
 */
public class Token {

    public static final int TOKEN_EXPIRES_HOUR = 2;


}
