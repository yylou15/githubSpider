package csu.coderwu.csuhelp.wx.mini.config;

/**
 * @author : coderWu
 * @date : Created on 18:50 2018/5/26
 */
public class Constants {

    public static final String TOKEN_KEY = "X-Chelp-Token";

    public static final String INNER_OPENID = "inner_openid";

}
