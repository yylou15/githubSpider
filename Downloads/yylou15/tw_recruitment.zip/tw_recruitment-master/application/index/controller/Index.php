<?php
namespace app\index\controller;

use think\db;
use think\Model;
use app\index\model\test;
class Index
{
    public function index()
    {
        return "Hello.summer!";
    }
}
